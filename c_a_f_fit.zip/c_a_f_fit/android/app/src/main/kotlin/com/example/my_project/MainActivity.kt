package com.mycompany.caffit

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
