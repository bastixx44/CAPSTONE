import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:timeago/timeago.dart' as timeago;
import 'lat_lng.dart';
import 'place.dart';
import 'uploaded_file.dart';
import '/backend/backend.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '/auth/firebase_auth/auth_util.dart';

double calcularIMC(
  int peso,
  int altura,
  DateTime edad,
) {
  // crea una funcion que calcule el IMC del usuario los argumentos se extraen desde las base de datos y se ocuparan peso, altura ambos de tipo Integer y fecha_nacimiento que se recibe como DateTime pero este debe calcular la edad del usuario y quedar como integer
  // Calculate age from birth date
  int age = DateTime.now().year - edad.year;

  // Calculate BMI
  double alturaMetros = altura / 100;
  double imc = (peso / (math.pow(alturaMetros, 2))) / 100;

  return imc;
}

int calcularedad(DateTime fechanacimiento) {
  // crea una funcion donde se reciba una variable de tipo datetime que sera la fechadenacimiento del usuario y se usara para calcular sus edad actual
  // Calculate age from birth date
  int age = DateTime.now().year - fechanacimiento.year;

  return age;
}

DateTime veinteycuatrohoras(DateTime currentime) {
  // CREA UNA FUNCION QUE RETORNE LAS ULTIMAS 12 HORAS DESDE EL CURRENT_TIME
  // Calculate the time 12 hours ago from the current time
  DateTime twelveHoursAgo = currentime.subtract(Duration(hours: 24));

  return twelveHoursAgo;
}

double? averageRatingBar(List<int>? ratingList) {
  // crea una funcion para poder calulcar el promedio del ratingbar
  // Check if the ratingList is not null and not empty
  if (ratingList != null && ratingList.isNotEmpty) {
    // Calculate the sum of all ratings in the list
    int sumOfRatings = ratingList.reduce((value, element) => value + element);

    // Calculate the average rating by dividing the sum of ratings by the number of ratings
    double averageRating = sumOfRatings / ratingList.length.toDouble();

    return averageRating;
  } else {
    return 0;
  }
}

int contador(
  DateTime currentTime,
  DateTime horaReserva,
) {
  // crea una funcion que cumpla como temporizador recibe dos parametors el primero que es el current time y luego la hora de reserva la cual es la hora para que el temporizador termine
  // Calculate the difference in seconds between the current time and the reservation time
  int differenceInSeconds = horaReserva.difference(currentTime).inSeconds;

  return differenceInSeconds;
}

int? calcularDiasConsecutivos() {
  // calcular los dias consecutivos de asistencia
// Create a list of attendance records for a user
  List<DateTime> attendanceRecords = [
    DateTime(2022, 10, 1),
    DateTime(2022, 10, 2),
    DateTime(2022, 10, 4),
    DateTime(2022, 10, 5),
    DateTime(2022, 10, 6),
  ];

// Sort the attendance records in ascending order
  attendanceRecords.sort();

// Initialize variables
  int maxConsecutiveDays = 0;
  int currentConsecutiveDays = 1;

// Calculate consecutive days of attendance
  for (int i = 1; i < attendanceRecords.length; i++) {
    // Calculate the difference in days between consecutive attendance records
    int diffInDays =
        attendanceRecords[i].difference(attendanceRecords[i - 1]).inDays;

    if (diffInDays == 1) {
      // If the attendance records are consecutive, increment the current consecutive days
      currentConsecutiveDays++;
    } else {
      // If the attendance records are not consecutive, update the maximum consecutive days
      maxConsecutiveDays = math.max(maxConsecutiveDays, currentConsecutiveDays);
      currentConsecutiveDays = 1;
    }
  }

// Update the maximum consecutive days considering the last set of attendance records
  maxConsecutiveDays = math.max(maxConsecutiveDays, currentConsecutiveDays);

  return maxConsecutiveDays;
}

int contarAsistencia(DocumentReference docreservas) {
  // haz una funcion que cuentes los true de una columna
  int count = 0;

  // Query the Firestore collection for the specified document reference
  docreservas.get().then((DocumentSnapshot snapshot) {
    if (snapshot.exists) {
      // Get the data from the document
      Map<String, dynamic> data = snapshot.data() as Map<String, dynamic>;

      // Check if the 'asistencia' field exists and count the number of 'true' values
      if (data.containsKey('asistencia')) {
        List<dynamic> asistenciaList = data['asistencia'];
        count = asistenciaList.where((element) => element == true).length;
      }
    }
  });

  return count;
}

double ratingbar(int rating) {
  // crea una funcion que sume todas las valoraciones del rating bar y calcule este mismo
  // Create a function to calculate the rating based on the sum of all ratings
  double totalRating = rating.toDouble();
  double maxRating = 5.0;

  // Calculate the rating percentage
  double ratingPercentage = (totalRating / (maxRating * rating)).toDouble();

  return ratingPercentage;
}
