import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: const FirebaseOptions(
            apiKey: "AIzaSyA3l_kCxwKgl9gspr_sXGS0CnKLAIXC4Co",
            authDomain: "c-a-f-fit-gw8pso.firebaseapp.com",
            projectId: "c-a-f-fit-gw8pso",
            storageBucket: "c-a-f-fit-gw8pso.appspot.com",
            messagingSenderId: "805620543250",
            appId: "1:805620543250:web:9e7d0a6a080083782c4dcb",
            measurementId: "G-NNNE8JWP1H"));
  } else {
    await Firebase.initializeApp();
  }
}
