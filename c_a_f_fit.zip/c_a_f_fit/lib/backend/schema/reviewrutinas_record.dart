import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class ReviewrutinasRecord extends FirestoreRecord {
  ReviewrutinasRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "user" field.
  DocumentReference? _user;
  DocumentReference? get user => _user;
  bool hasUser() => _user != null;

  // "review" field.
  String? _review;
  String get review => _review ?? '';
  bool hasReview() => _review != null;

  // "rating" field.
  int? _rating;
  int get rating => _rating ?? 0;
  bool hasRating() => _rating != null;

  // "created_time" field.
  DateTime? _createdTime;
  DateTime? get createdTime => _createdTime;
  bool hasCreatedTime() => _createdTime != null;

  DocumentReference get parentReference => reference.parent.parent!;

  void _initializeFields() {
    _user = snapshotData['user'] as DocumentReference?;
    _review = snapshotData['review'] as String?;
    _rating = castToType<int>(snapshotData['rating']);
    _createdTime = snapshotData['created_time'] as DateTime?;
  }

  static Query<Map<String, dynamic>> collection([DocumentReference? parent]) =>
      parent != null
          ? parent.collection('reviewrutinas')
          : FirebaseFirestore.instance.collectionGroup('reviewrutinas');

  static DocumentReference createDoc(DocumentReference parent, {String? id}) =>
      parent.collection('reviewrutinas').doc(id);

  static Stream<ReviewrutinasRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => ReviewrutinasRecord.fromSnapshot(s));

  static Future<ReviewrutinasRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => ReviewrutinasRecord.fromSnapshot(s));

  static ReviewrutinasRecord fromSnapshot(DocumentSnapshot snapshot) =>
      ReviewrutinasRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static ReviewrutinasRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      ReviewrutinasRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'ReviewrutinasRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is ReviewrutinasRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createReviewrutinasRecordData({
  DocumentReference? user,
  String? review,
  int? rating,
  DateTime? createdTime,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'user': user,
      'review': review,
      'rating': rating,
      'created_time': createdTime,
    }.withoutNulls,
  );

  return firestoreData;
}

class ReviewrutinasRecordDocumentEquality
    implements Equality<ReviewrutinasRecord> {
  const ReviewrutinasRecordDocumentEquality();

  @override
  bool equals(ReviewrutinasRecord? e1, ReviewrutinasRecord? e2) {
    return e1?.user == e2?.user &&
        e1?.review == e2?.review &&
        e1?.rating == e2?.rating &&
        e1?.createdTime == e2?.createdTime;
  }

  @override
  int hash(ReviewrutinasRecord? e) => const ListEquality()
      .hash([e?.user, e?.review, e?.rating, e?.createdTime]);

  @override
  bool isValidKey(Object? o) => o is ReviewrutinasRecord;
}
