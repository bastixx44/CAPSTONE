import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class SesionesRecord extends FirestoreRecord {
  SesionesRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "nombre" field.
  String? _nombre;
  String get nombre => _nombre ?? '';
  bool hasNombre() => _nombre != null;

  // "descripcion" field.
  String? _descripcion;
  String get descripcion => _descripcion ?? '';
  bool hasDescripcion() => _descripcion != null;

  // "capacidad" field.
  int? _capacidad;
  int get capacidad => _capacidad ?? 0;
  bool hasCapacidad() => _capacidad != null;

  // "disponible" field.
  bool? _disponible;
  bool get disponible => _disponible ?? false;
  bool hasDisponible() => _disponible != null;

  // "fecha_sesion" field.
  DateTime? _fechaSesion;
  DateTime? get fechaSesion => _fechaSesion;
  bool hasFechaSesion() => _fechaSesion != null;

  // "hora_inicio" field.
  DateTime? _horaInicio;
  DateTime? get horaInicio => _horaInicio;
  bool hasHoraInicio() => _horaInicio != null;

  // "duracion" field.
  String? _duracion;
  String get duracion => _duracion ?? '';
  bool hasDuracion() => _duracion != null;

  // "cupo_actual" field.
  int? _cupoActual;
  int get cupoActual => _cupoActual ?? 0;
  bool hasCupoActual() => _cupoActual != null;

  // "created_time" field.
  DateTime? _createdTime;
  DateTime? get createdTime => _createdTime;
  bool hasCreatedTime() => _createdTime != null;

  void _initializeFields() {
    _nombre = snapshotData['nombre'] as String?;
    _descripcion = snapshotData['descripcion'] as String?;
    _capacidad = castToType<int>(snapshotData['capacidad']);
    _disponible = snapshotData['disponible'] as bool?;
    _fechaSesion = snapshotData['fecha_sesion'] as DateTime?;
    _horaInicio = snapshotData['hora_inicio'] as DateTime?;
    _duracion = snapshotData['duracion'] as String?;
    _cupoActual = castToType<int>(snapshotData['cupo_actual']);
    _createdTime = snapshotData['created_time'] as DateTime?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('sesiones');

  static Stream<SesionesRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => SesionesRecord.fromSnapshot(s));

  static Future<SesionesRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => SesionesRecord.fromSnapshot(s));

  static SesionesRecord fromSnapshot(DocumentSnapshot snapshot) =>
      SesionesRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static SesionesRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      SesionesRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'SesionesRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is SesionesRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createSesionesRecordData({
  String? nombre,
  String? descripcion,
  int? capacidad,
  bool? disponible,
  DateTime? fechaSesion,
  DateTime? horaInicio,
  String? duracion,
  int? cupoActual,
  DateTime? createdTime,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'nombre': nombre,
      'descripcion': descripcion,
      'capacidad': capacidad,
      'disponible': disponible,
      'fecha_sesion': fechaSesion,
      'hora_inicio': horaInicio,
      'duracion': duracion,
      'cupo_actual': cupoActual,
      'created_time': createdTime,
    }.withoutNulls,
  );

  return firestoreData;
}

class SesionesRecordDocumentEquality implements Equality<SesionesRecord> {
  const SesionesRecordDocumentEquality();

  @override
  bool equals(SesionesRecord? e1, SesionesRecord? e2) {
    return e1?.nombre == e2?.nombre &&
        e1?.descripcion == e2?.descripcion &&
        e1?.capacidad == e2?.capacidad &&
        e1?.disponible == e2?.disponible &&
        e1?.fechaSesion == e2?.fechaSesion &&
        e1?.horaInicio == e2?.horaInicio &&
        e1?.duracion == e2?.duracion &&
        e1?.cupoActual == e2?.cupoActual &&
        e1?.createdTime == e2?.createdTime;
  }

  @override
  int hash(SesionesRecord? e) => const ListEquality().hash([
        e?.nombre,
        e?.descripcion,
        e?.capacidad,
        e?.disponible,
        e?.fechaSesion,
        e?.horaInicio,
        e?.duracion,
        e?.cupoActual,
        e?.createdTime
      ]);

  @override
  bool isValidKey(Object? o) => o is SesionesRecord;
}
