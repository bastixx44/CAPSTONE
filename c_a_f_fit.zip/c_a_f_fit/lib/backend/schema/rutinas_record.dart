import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class RutinasRecord extends FirestoreRecord {
  RutinasRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "nombrerutina" field.
  String? _nombrerutina;
  String get nombrerutina => _nombrerutina ?? '';
  bool hasNombrerutina() => _nombrerutina != null;

  // "rating" field.
  List<int>? _rating;
  List<int> get rating => _rating ?? const [];
  bool hasRating() => _rating != null;

  void _initializeFields() {
    _nombrerutina = snapshotData['nombrerutina'] as String?;
    _rating = getDataList(snapshotData['rating']);
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('Rutinas');

  static Stream<RutinasRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => RutinasRecord.fromSnapshot(s));

  static Future<RutinasRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => RutinasRecord.fromSnapshot(s));

  static RutinasRecord fromSnapshot(DocumentSnapshot snapshot) =>
      RutinasRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static RutinasRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      RutinasRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'RutinasRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is RutinasRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createRutinasRecordData({
  String? nombrerutina,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'nombrerutina': nombrerutina,
    }.withoutNulls,
  );

  return firestoreData;
}

class RutinasRecordDocumentEquality implements Equality<RutinasRecord> {
  const RutinasRecordDocumentEquality();

  @override
  bool equals(RutinasRecord? e1, RutinasRecord? e2) {
    const listEquality = ListEquality();
    return e1?.nombrerutina == e2?.nombrerutina &&
        listEquality.equals(e1?.rating, e2?.rating);
  }

  @override
  int hash(RutinasRecord? e) =>
      const ListEquality().hash([e?.nombrerutina, e?.rating]);

  @override
  bool isValidKey(Object? o) => o is RutinasRecord;
}
