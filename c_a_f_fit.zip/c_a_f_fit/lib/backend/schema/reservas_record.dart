import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class ReservasRecord extends FirestoreRecord {
  ReservasRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "fecha_reserva" field.
  DateTime? _fechaReserva;
  DateTime? get fechaReserva => _fechaReserva;
  bool hasFechaReserva() => _fechaReserva != null;

  // "hora_reserva" field.
  DateTime? _horaReserva;
  DateTime? get horaReserva => _horaReserva;
  bool hasHoraReserva() => _horaReserva != null;

  // "nombre_sesion" field.
  String? _nombreSesion;
  String get nombreSesion => _nombreSesion ?? '';
  bool hasNombreSesion() => _nombreSesion != null;

  // "user" field.
  DocumentReference? _user;
  DocumentReference? get user => _user;
  bool hasUser() => _user != null;

  // "asistencia" field.
  bool? _asistencia;
  bool get asistencia => _asistencia ?? false;
  bool hasAsistencia() => _asistencia != null;

  // "email" field.
  String? _email;
  String get email => _email ?? '';
  bool hasEmail() => _email != null;

  // "created_time" field.
  DateTime? _createdTime;
  DateTime? get createdTime => _createdTime;
  bool hasCreatedTime() => _createdTime != null;

  void _initializeFields() {
    _fechaReserva = snapshotData['fecha_reserva'] as DateTime?;
    _horaReserva = snapshotData['hora_reserva'] as DateTime?;
    _nombreSesion = snapshotData['nombre_sesion'] as String?;
    _user = snapshotData['user'] as DocumentReference?;
    _asistencia = snapshotData['asistencia'] as bool?;
    _email = snapshotData['email'] as String?;
    _createdTime = snapshotData['created_time'] as DateTime?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('reservas');

  static Stream<ReservasRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => ReservasRecord.fromSnapshot(s));

  static Future<ReservasRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => ReservasRecord.fromSnapshot(s));

  static ReservasRecord fromSnapshot(DocumentSnapshot snapshot) =>
      ReservasRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static ReservasRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      ReservasRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'ReservasRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is ReservasRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createReservasRecordData({
  DateTime? fechaReserva,
  DateTime? horaReserva,
  String? nombreSesion,
  DocumentReference? user,
  bool? asistencia,
  String? email,
  DateTime? createdTime,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'fecha_reserva': fechaReserva,
      'hora_reserva': horaReserva,
      'nombre_sesion': nombreSesion,
      'user': user,
      'asistencia': asistencia,
      'email': email,
      'created_time': createdTime,
    }.withoutNulls,
  );

  return firestoreData;
}

class ReservasRecordDocumentEquality implements Equality<ReservasRecord> {
  const ReservasRecordDocumentEquality();

  @override
  bool equals(ReservasRecord? e1, ReservasRecord? e2) {
    return e1?.fechaReserva == e2?.fechaReserva &&
        e1?.horaReserva == e2?.horaReserva &&
        e1?.nombreSesion == e2?.nombreSesion &&
        e1?.user == e2?.user &&
        e1?.asistencia == e2?.asistencia &&
        e1?.email == e2?.email &&
        e1?.createdTime == e2?.createdTime;
  }

  @override
  int hash(ReservasRecord? e) => const ListEquality().hash([
        e?.fechaReserva,
        e?.horaReserva,
        e?.nombreSesion,
        e?.user,
        e?.asistencia,
        e?.email,
        e?.createdTime
      ]);

  @override
  bool isValidKey(Object? o) => o is ReservasRecord;
}
