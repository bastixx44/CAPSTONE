import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'flutter_flow/flutter_flow_util.dart';

class FFAppState extends ChangeNotifier {
  static FFAppState _instance = FFAppState._internal();

  factory FFAppState() {
    return _instance;
  }

  FFAppState._internal();

  static void reset() {
    _instance = FFAppState._internal();
  }

  Future initializePersistedState() async {
    prefs = await SharedPreferences.getInstance();
    _safeInit(() {
      _rutinaList = prefs
              .getStringList('ff_rutinaList')
              ?.map((path) => path.ref)
              .toList() ??
          _rutinaList;
    });
  }

  void update(VoidCallback callback) {
    callback();
    notifyListeners();
  }

  late SharedPreferences prefs;

  List<DocumentReference> _rutinaList = [];
  List<DocumentReference> get rutinaList => _rutinaList;
  set rutinaList(List<DocumentReference> value) {
    _rutinaList = value;
    prefs.setStringList('ff_rutinaList', value.map((x) => x.path).toList());
  }

  void addToRutinaList(DocumentReference value) {
    rutinaList.add(value);
    prefs.setStringList(
        'ff_rutinaList', _rutinaList.map((x) => x.path).toList());
  }

  void removeFromRutinaList(DocumentReference value) {
    rutinaList.remove(value);
    prefs.setStringList(
        'ff_rutinaList', _rutinaList.map((x) => x.path).toList());
  }

  void removeAtIndexFromRutinaList(int index) {
    rutinaList.removeAt(index);
    prefs.setStringList(
        'ff_rutinaList', _rutinaList.map((x) => x.path).toList());
  }

  void updateRutinaListAtIndex(
    int index,
    DocumentReference Function(DocumentReference) updateFn,
  ) {
    rutinaList[index] = updateFn(_rutinaList[index]);
    prefs.setStringList(
        'ff_rutinaList', _rutinaList.map((x) => x.path).toList());
  }

  void insertAtIndexInRutinaList(int index, DocumentReference value) {
    rutinaList.insert(index, value);
    prefs.setStringList(
        'ff_rutinaList', _rutinaList.map((x) => x.path).toList());
  }
}

void _safeInit(Function() initializeField) {
  try {
    initializeField();
  } catch (_) {}
}

Future _safeInitAsync(Function() initializeField) async {
  try {
    await initializeField();
  } catch (_) {}
}
