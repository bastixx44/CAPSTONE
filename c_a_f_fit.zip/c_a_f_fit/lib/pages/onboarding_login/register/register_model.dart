import '/components/primary_button/primary_button_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'register_widget.dart' show RegisterWidget;
import 'package:flutter/material.dart';

class RegisterModel extends FlutterFlowModel<RegisterWidget> {
  ///  State fields for stateful widgets in this page.

  // State field(s) for nombre_apellido widget.
  FocusNode? nombreApellidoFocusNode;
  TextEditingController? nombreApellidoTextController;
  String? Function(BuildContext, String?)?
      nombreApellidoTextControllerValidator;
  // State field(s) for diplay_name widget.
  FocusNode? diplayNameFocusNode;
  TextEditingController? diplayNameTextController;
  String? Function(BuildContext, String?)? diplayNameTextControllerValidator;
  // State field(s) for email widget.
  FocusNode? emailFocusNode;
  TextEditingController? emailTextController;
  String? Function(BuildContext, String?)? emailTextControllerValidator;
  // State field(s) for password widget.
  FocusNode? passwordFocusNode;
  TextEditingController? passwordTextController;
  late bool passwordVisibility;
  String? Function(BuildContext, String?)? passwordTextControllerValidator;
  // Model for primaryButton component.
  late PrimaryButtonModel primaryButtonModel;

  @override
  void initState(BuildContext context) {
    passwordVisibility = false;
    primaryButtonModel = createModel(context, () => PrimaryButtonModel());
  }

  @override
  void dispose() {
    nombreApellidoFocusNode?.dispose();
    nombreApellidoTextController?.dispose();

    diplayNameFocusNode?.dispose();
    diplayNameTextController?.dispose();

    emailFocusNode?.dispose();
    emailTextController?.dispose();

    passwordFocusNode?.dispose();
    passwordTextController?.dispose();

    primaryButtonModel.dispose();
  }
}
