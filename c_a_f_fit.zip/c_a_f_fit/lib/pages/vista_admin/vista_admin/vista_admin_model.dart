import '/flutter_flow/flutter_flow_util.dart';
import 'vista_admin_widget.dart' show VistaAdminWidget;
import 'package:flutter/material.dart';

class VistaAdminModel extends FlutterFlowModel<VistaAdminWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
