import '/flutter_flow/flutter_flow_util.dart';
import 'listareviews_widget.dart' show ListareviewsWidget;
import 'package:flutter/material.dart';

class ListareviewsModel extends FlutterFlowModel<ListareviewsWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
