import '/flutter_flow/flutter_flow_util.dart';
import 'chatbot_widget.dart' show ChatbotWidget;
import 'package:flutter/material.dart';

class ChatbotModel extends FlutterFlowModel<ChatbotWidget> {
  ///  State fields for stateful widgets in this page.

  // State field(s) for txtPrompt widget.
  FocusNode? txtPromptFocusNode;
  TextEditingController? txtPromptTextController;
  String? Function(BuildContext, String?)? txtPromptTextControllerValidator;
  // Stores action output result for [Gemini - Generate Text] action in btnSubmit widget.
  String? respuesta;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    txtPromptFocusNode?.dispose();
    txtPromptTextController?.dispose();
  }
}
