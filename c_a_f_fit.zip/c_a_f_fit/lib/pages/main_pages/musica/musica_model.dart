import '/flutter_flow/flutter_flow_util.dart';
import 'musica_widget.dart' show MusicaWidget;
import 'package:flutter/material.dart';

class MusicaModel extends FlutterFlowModel<MusicaWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
