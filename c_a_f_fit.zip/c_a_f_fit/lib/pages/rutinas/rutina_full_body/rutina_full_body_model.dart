import '/flutter_flow/flutter_flow_util.dart';
import 'rutina_full_body_widget.dart' show RutinaFullBodyWidget;
import 'package:flutter/material.dart';

class RutinaFullBodyModel extends FlutterFlowModel<RutinaFullBodyWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
