import '/flutter_flow/flutter_flow_util.dart';
import 'rutinas_main_widget.dart' show RutinasMainWidget;
import 'package:flutter/material.dart';

class RutinasMainModel extends FlutterFlowModel<RutinasMainWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
