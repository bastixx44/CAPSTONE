// Export pages
export '/pages/main_pages/home/home_widget.dart' show HomeWidget;
export '/pages/onboarding_login/welcome/welcome_widget.dart' show WelcomeWidget;
export '/pages/onboarding_login/onboarding/onboarding_widget.dart'
    show OnboardingWidget;
export '/pages/onboarding_login/register/register_widget.dart'
    show RegisterWidget;
export '/pages/onboarding_login/complete_profile/complete_profile_widget.dart'
    show CompleteProfileWidget;
export '/pages/onboarding_login/login/login_widget.dart' show LoginWidget;
export '/pages/onboarding_login/registration_success/registration_success_widget.dart'
    show RegistrationSuccessWidget;
export '/pages/main_pages/profile/profile_widget.dart' show ProfileWidget;
export '/pages/main_pages/agendar/agendar_widget.dart' show AgendarWidget;
export '/pages/vista_admin/vista_admin/vista_admin_widget.dart'
    show VistaAdminWidget;
export '/pages/rutinas/rutinas_main/rutinas_main_widget.dart'
    show RutinasMainWidget;
export '/pages/rutinas/rutina_pierna/rutina_pierna_widget.dart'
    show RutinaPiernaWidget;
export '/pages/rutinas/rutina_pectoral/rutina_pectoral_widget.dart'
    show RutinaPectoralWidget;
export '/pages/rutinas/rutina_espalda/rutina_espalda_widget.dart'
    show RutinaEspaldaWidget;
export '/pages/rutinas/rutina_full_body/rutina_full_body_widget.dart'
    show RutinaFullBodyWidget;
export '/pages/vista_admin/escoger_session_asistencia/escoger_session_asistencia_widget.dart'
    show EscogerSessionAsistenciaWidget;
export '/pages/cuenta_usuario/datos_personales/datos_personales_widget.dart'
    show DatosPersonalesWidget;
export '/pages/cuenta_usuario/edit_profile/edit_profile_widget.dart'
    show EditProfileWidget;
export '/pages/vista_admin/lista_de_sesiones/lista_de_sesiones_widget.dart'
    show ListaDeSesionesWidget;
export '/pages/cuenta_usuario/listareviews/listareviews_widget.dart'
    show ListareviewsWidget;
export '/pages/main_pages/musica/musica_widget.dart' show MusicaWidget;
export '/pages/main_pages/chatbot/chatbot_widget.dart' show ChatbotWidget;
export '/pages/vista_admin/lista_asistencia/lista_asistencia_widget.dart'
    show ListaAsistenciaWidget;
