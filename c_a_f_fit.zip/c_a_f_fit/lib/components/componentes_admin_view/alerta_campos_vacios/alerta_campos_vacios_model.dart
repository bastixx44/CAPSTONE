import '/flutter_flow/flutter_flow_util.dart';
import 'alerta_campos_vacios_widget.dart' show AlertaCamposVaciosWidget;
import 'package:flutter/material.dart';

class AlertaCamposVaciosModel
    extends FlutterFlowModel<AlertaCamposVaciosWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
