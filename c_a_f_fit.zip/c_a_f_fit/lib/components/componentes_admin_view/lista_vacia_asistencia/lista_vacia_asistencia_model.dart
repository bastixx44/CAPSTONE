import '/flutter_flow/flutter_flow_util.dart';
import 'lista_vacia_asistencia_widget.dart' show ListaVaciaAsistenciaWidget;
import 'package:flutter/material.dart';

class ListaVaciaAsistenciaModel
    extends FlutterFlowModel<ListaVaciaAsistenciaWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
