import '/flutter_flow/flutter_flow_util.dart';
import 'aviso_eliminar_widget.dart' show AvisoEliminarWidget;
import 'package:flutter/material.dart';

class AvisoEliminarModel extends FlutterFlowModel<AvisoEliminarWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
