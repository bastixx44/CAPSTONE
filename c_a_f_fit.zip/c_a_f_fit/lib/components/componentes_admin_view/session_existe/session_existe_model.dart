import '/flutter_flow/flutter_flow_util.dart';
import 'session_existe_widget.dart' show SessionExisteWidget;
import 'package:flutter/material.dart';

class SessionExisteModel extends FlutterFlowModel<SessionExisteWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
