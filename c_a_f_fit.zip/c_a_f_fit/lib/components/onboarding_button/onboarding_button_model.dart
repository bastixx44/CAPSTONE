import '/flutter_flow/flutter_flow_util.dart';
import 'onboarding_button_widget.dart' show OnboardingButtonWidget;
import 'package:flutter/material.dart';

class OnboardingButtonModel extends FlutterFlowModel<OnboardingButtonWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
