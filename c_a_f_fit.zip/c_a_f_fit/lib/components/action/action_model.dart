import '/flutter_flow/flutter_flow_util.dart';
import 'action_widget.dart' show ActionWidget;
import 'package:flutter/material.dart';

class ActionModel extends FlutterFlowModel<ActionWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
