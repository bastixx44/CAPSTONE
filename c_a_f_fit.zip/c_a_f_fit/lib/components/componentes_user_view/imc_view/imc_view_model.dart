import '/flutter_flow/flutter_flow_util.dart';
import 'imc_view_widget.dart' show ImcViewWidget;
import 'package:flutter/material.dart';

class ImcViewModel extends FlutterFlowModel<ImcViewWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
