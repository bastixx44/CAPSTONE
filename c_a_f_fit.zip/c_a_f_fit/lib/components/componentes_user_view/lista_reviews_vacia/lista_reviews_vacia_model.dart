import '/flutter_flow/flutter_flow_util.dart';
import 'lista_reviews_vacia_widget.dart' show ListaReviewsVaciaWidget;
import 'package:flutter/material.dart';

class ListaReviewsVaciaModel extends FlutterFlowModel<ListaReviewsVaciaWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
