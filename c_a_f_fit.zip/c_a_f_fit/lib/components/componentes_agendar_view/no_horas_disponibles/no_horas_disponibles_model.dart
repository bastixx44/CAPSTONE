import '/flutter_flow/flutter_flow_util.dart';
import 'no_horas_disponibles_widget.dart' show NoHorasDisponiblesWidget;
import 'package:flutter/material.dart';

class NoHorasDisponiblesModel
    extends FlutterFlowModel<NoHorasDisponiblesWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
