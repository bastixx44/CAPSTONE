import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/form_field_controller.dart';
import 'crear_sesion_widget.dart' show CrearSesionWidget;
import 'package:flutter/material.dart';

class CrearSesionModel extends FlutterFlowModel<CrearSesionWidget> {
  ///  State fields for stateful widgets in this component.

  // State field(s) for NombreSesion widget.
  FocusNode? nombreSesionFocusNode;
  TextEditingController? nombreSesionTextController;
  String? Function(BuildContext, String?)? nombreSesionTextControllerValidator;
  // State field(s) for Descripcion widget.
  FocusNode? descripcionFocusNode;
  TextEditingController? descripcionTextController;
  String? Function(BuildContext, String?)? descripcionTextControllerValidator;
  // State field(s) for capacidad widget.
  FocusNode? capacidadFocusNode;
  TextEditingController? capacidadTextController;
  String? Function(BuildContext, String?)? capacidadTextControllerValidator;
  DateTime? datePicked1;
  // State field(s) for duracion widget.
  String? duracionValue;
  FormFieldController<String>? duracionValueController;
  DateTime? datePicked2;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    nombreSesionFocusNode?.dispose();
    nombreSesionTextController?.dispose();

    descripcionFocusNode?.dispose();
    descripcionTextController?.dispose();

    capacidadFocusNode?.dispose();
    capacidadTextController?.dispose();
  }
}
