import '/flutter_flow/flutter_flow_util.dart';
import 'no_sesiones_disponibles_widget.dart' show NoSesionesDisponiblesWidget;
import 'package:flutter/material.dart';

class NoSesionesDisponiblesModel
    extends FlutterFlowModel<NoSesionesDisponiblesWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
