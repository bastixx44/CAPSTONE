import '/flutter_flow/flutter_flow_util.dart';
import 'sesion_duplicada_widget.dart' show SesionDuplicadaWidget;
import 'package:flutter/material.dart';

class SesionDuplicadaModel extends FlutterFlowModel<SesionDuplicadaWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
