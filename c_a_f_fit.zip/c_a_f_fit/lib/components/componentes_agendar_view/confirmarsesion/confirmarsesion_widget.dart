import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/components/componentes_agendar_view/sesion_duplicada/sesion_duplicada_widget.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'confirmarsesion_model.dart';
export 'confirmarsesion_model.dart';

class ConfirmarsesionWidget extends StatefulWidget {
  const ConfirmarsesionWidget({
    super.key,
    required this.sesionesRef,
    this.nombreSesion,
    this.fechaSesion,
    this.horaSesion,
    this.user,
  });

  final DocumentReference? sesionesRef;
  final String? nombreSesion;
  final DateTime? fechaSesion;
  final DateTime? horaSesion;
  final DocumentReference? user;

  @override
  State<ConfirmarsesionWidget> createState() => _ConfirmarsesionWidgetState();
}

class _ConfirmarsesionWidgetState extends State<ConfirmarsesionWidget> {
  late ConfirmarsesionModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => ConfirmarsesionModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsetsDirectional.fromSTEB(16.0, 16.0, 16.0, 16.0),
      child: StreamBuilder<SesionesRecord>(
        stream: SesionesRecord.getDocument(widget.sesionesRef!),
        builder: (context, snapshot) {
          // Customize what your widget looks like when it's loading.
          if (!snapshot.hasData) {
            return Center(
              child: SizedBox(
                width: 50.0,
                height: 50.0,
                child: SpinKitChasingDots(
                  color: FlutterFlowTheme.of(context).primary,
                  size: 50.0,
                ),
              ),
            );
          }

          final containerSesionesRecord = snapshot.data!;

          return Container(
            width: double.infinity,
            decoration: BoxDecoration(
              color: FlutterFlowTheme.of(context).secondaryBackground,
              boxShadow: const [
                BoxShadow(
                  blurRadius: 4.0,
                  color: Color(0x33000000),
                  offset: Offset(
                    0.0,
                    2.0,
                  ),
                  spreadRadius: 0.0,
                )
              ],
              borderRadius: BorderRadius.circular(12.0),
            ),
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Confirmar Sesión',
                    style: FlutterFlowTheme.of(context).headlineSmall.override(
                          fontFamily: 'Poppins',
                          color: FlutterFlowTheme.of(context).primaryText,
                          fontSize: 26.0,
                          letterSpacing: 0.0,
                        ),
                  ),
                  Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Flexible(
                            child: Text(
                              'Nombre:',
                              style: FlutterFlowTheme.of(context)
                                  .bodyMedium
                                  .override(
                                    fontFamily: 'Poppins',
                                    color: FlutterFlowTheme.of(context)
                                        .secondaryText,
                                    fontSize: 18.0,
                                    letterSpacing: 0.0,
                                  ),
                            ),
                          ),
                          Text(
                            valueOrDefault<String>(
                              widget.nombreSesion,
                              'Nombre Sesion',
                            ).maybeHandleOverflow(
                              maxChars: 18,
                              replacement: '…',
                            ),
                            textAlign: TextAlign.start,
                            style: FlutterFlowTheme.of(context)
                                .bodyMedium
                                .override(
                                  fontFamily: 'Poppins',
                                  color:
                                      FlutterFlowTheme.of(context).primaryText,
                                  fontSize: 16.0,
                                  letterSpacing: 0.0,
                                ),
                          ),
                        ],
                      ),
                      Row(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Flexible(
                            child: Text(
                              'Fecha:',
                              style: FlutterFlowTheme.of(context)
                                  .bodyMedium
                                  .override(
                                    fontFamily: 'Poppins',
                                    color: FlutterFlowTheme.of(context)
                                        .secondaryText,
                                    fontSize: 18.0,
                                    letterSpacing: 0.0,
                                  ),
                            ),
                          ),
                          Flexible(
                            child: Text(
                              dateTimeFormat("yMd", widget.fechaSesion),
                              style: FlutterFlowTheme.of(context)
                                  .bodyMedium
                                  .override(
                                    fontFamily: 'Poppins',
                                    color: FlutterFlowTheme.of(context)
                                        .primaryText,
                                    fontSize: 18.0,
                                    letterSpacing: 0.0,
                                  ),
                            ),
                          ),
                        ],
                      ),
                      Row(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Flexible(
                            child: Text(
                              'Hora:',
                              style: FlutterFlowTheme.of(context)
                                  .bodyMedium
                                  .override(
                                    fontFamily: 'Poppins',
                                    color: FlutterFlowTheme.of(context)
                                        .secondaryText,
                                    fontSize: 18.0,
                                    letterSpacing: 0.0,
                                  ),
                            ),
                          ),
                          Flexible(
                            child: Text(
                              dateTimeFormat("jm", widget.horaSesion),
                              style: FlutterFlowTheme.of(context)
                                  .bodyMedium
                                  .override(
                                    fontFamily: 'Poppins',
                                    color: FlutterFlowTheme.of(context)
                                        .primaryText,
                                    fontSize: 18.0,
                                    letterSpacing: 0.0,
                                  ),
                            ),
                          ),
                        ],
                      ),
                    ].divide(const SizedBox(height: 8.0)),
                  ),
                  StreamBuilder<List<ReservasRecord>>(
                    stream: queryReservasRecord(
                      queryBuilder: (reservasRecord) => reservasRecord
                          .where(
                            'fecha_reserva',
                            isEqualTo: widget.fechaSesion,
                          )
                          .where(
                            'hora_reserva',
                            isEqualTo: widget.horaSesion,
                          )
                          .where(
                            'email',
                            isEqualTo: currentUserEmail,
                          ),
                      singleRecord: true,
                    ),
                    builder: (context, snapshot) {
                      // Customize what your widget looks like when it's loading.
                      if (!snapshot.hasData) {
                        return Center(
                          child: SizedBox(
                            width: 50.0,
                            height: 50.0,
                            child: SpinKitChasingDots(
                              color: FlutterFlowTheme.of(context).primary,
                              size: 50.0,
                            ),
                          ),
                        );
                      }
                      List<ReservasRecord> buttonReservasRecordList =
                          snapshot.data!;
                      final buttonReservasRecord =
                          buttonReservasRecordList.isNotEmpty
                              ? buttonReservasRecordList.first
                              : null;

                      return FFButtonWidget(
                        onPressed: () async {
                          if ((buttonReservasRecord?.fechaReserva != null) &&
                              (currentUserEmail != '')) {
                            await showModalBottomSheet(
                              isScrollControlled: true,
                              backgroundColor: Colors.transparent,
                              enableDrag: false,
                              context: context,
                              builder: (context) {
                                return Padding(
                                  padding: MediaQuery.viewInsetsOf(context),
                                  child: const SesionDuplicadaWidget(),
                                );
                              },
                            ).then((value) => safeSetState(() {}));
                          } else {
                            await ReservasRecord.collection
                                .doc()
                                .set(createReservasRecordData(
                                  fechaReserva: widget.fechaSesion,
                                  horaReserva: widget.horaSesion,
                                  nombreSesion: widget.nombreSesion,
                                  user: currentUserReference,
                                  email: currentUserEmail,
                                  asistencia: false,
                                  createdTime: getCurrentTimestamp,
                                ));

                            await containerSesionesRecord.reference.update({
                              ...mapToFirestore(
                                {
                                  'cupo_actual': FieldValue.increment(1),
                                },
                              ),
                            });
                            context.safePop();
                          }
                        },
                        text: 'Confirmar',
                        options: FFButtonOptions(
                          width: double.infinity,
                          height: 50.0,
                          padding: const EdgeInsetsDirectional.fromSTEB(
                              0.0, 0.0, 0.0, 0.0),
                          iconPadding: const EdgeInsetsDirectional.fromSTEB(
                              0.0, 0.0, 0.0, 0.0),
                          color: FlutterFlowTheme.of(context).primary,
                          textStyle:
                              FlutterFlowTheme.of(context).titleSmall.override(
                                    fontFamily: 'Poppins',
                                    color: FlutterFlowTheme.of(context)
                                        .primaryBackground,
                                    letterSpacing: 0.0,
                                  ),
                          elevation: 0.0,
                          borderRadius: BorderRadius.circular(25.0),
                        ),
                      );
                    },
                  ),
                ].divide(const SizedBox(height: 16.0)),
              ),
            ),
          );
        },
      ),
    );
  }
}
