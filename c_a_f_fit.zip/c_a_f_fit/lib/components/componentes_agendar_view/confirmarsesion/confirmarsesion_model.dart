import '/flutter_flow/flutter_flow_util.dart';
import 'confirmarsesion_widget.dart' show ConfirmarsesionWidget;
import 'package:flutter/material.dart';

class ConfirmarsesionModel extends FlutterFlowModel<ConfirmarsesionWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
